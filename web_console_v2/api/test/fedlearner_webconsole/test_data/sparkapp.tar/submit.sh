export HADOOP_HOME=/opt/tiger/yarn_deploy/hadoop
USER_DIR=hdfs://haruna/user/wangsen.0914
${HADOOP_HOME}/bin/hadoop fs -put -f convertor.py ${USER_DIR}/convertor/ &> /dev/null

export SPARK_HOME=/opt/tiger/spark-3.0/spark-stable
${SPARK_HOME}/bin/spark-submit \
    --master k8s://${KUBERNETES_SERVICE_HOST}:${KUBERNETES_SERVICE_PORT} \
    --deploy-mode cluster \
    --conf spark.kubernetes.namespace=${MY_POD_NAMESPACE} \
    --conf spark.app.name=fl_submit_convertor \
    --conf spark.shuffle.service.enabled=false \
    --conf spark.dynamicAllocation.enabled=false \
    --conf spark.kubernetes.container.image=hub.byted.org/tce/spark_tfrecords_base:8e8ff44278cadf70f4c70626656a0389 \
    --conf spark.kubernetes.container.image.pullPolicy=Always \
    --conf spark.kubernetes.submission.waitAppCompletion=true \
    --conf spark.driver.cores=1 \
    --conf spark.kubernetes.driver.limit.cores=1200m \
    --conf spark.driver.memory=512m \
    --conf spark.kubernetes.authenticate.driver.serviceAccountName=spark \
    --conf spark.kubernetes.driver.label.version=3.0.0 \
    --conf spark.kubernetes.driver.label.psm=bytedance.tce.spark_oprator \
    --conf spark.kubernetes.driver.label.owner=wangsen.0914 \
    --conf spark.executor.instances=1 \
    --conf spark.executor.cores=1 \
    --conf spark.executor.memory=512m \
    --conf spark.kubernetes.executor.label.owner=wangsen.0914 \
    --conf spark.kubernetes.executor.label.psm=bytedance.tce.spark_oprator \
    --conf spark.kubernetes.executor.label.version=3.0.0 \
    --conf spark.kubernetes.executor.deleteOnTermination=false \
    --conf spark.kubernetes.executor.extraClassPath=/opt/spark/ \
    --conf spark.kubernetes.driver.extraClassPath=/opt/spark/ \
    --conf spark.kubernetes.driver.volumes.hostPath.spark-deploy.mount.path=/opt/tiger/spark_deploy/spark-3.0 \
    --conf spark.kubernetes.driver.volumes.hostPath.spark-deploy.mount.readOnly=true \
    --conf spark.kubernetes.driver.volumes.hostPath.spark-deploy.options.path=/opt/tiger/spark_deploy/spark-3.0 \
    --conf spark.kubernetes.executor.volumes.hostPath.spark-deploy.mount.path=/opt/tiger/spark_deploy/spark-3.0 \
    --conf spark.kubernetes.executor.volumes.hostPath.spark-deploy.mount.readOnly=true \
    --conf spark.kubernetes.executor.volumes.hostPath.spark-deploy.options.path=/opt/tiger/spark_deploy/spark-3.0 \
    --conf spark.kubernetes.driver.volumes.hostPath.yarn-deploy.mount.path=/opt/tiger/yarn_deploy \
    --conf spark.kubernetes.driver.volumes.hostPath.yarn-deploy.mount.readOnly=true \
    --conf spark.eventLog.dir=hdfs://haruna/home/byte_tce_spark/spark_history_server/cloudnative-hl \
    --conf spark.eventLog.internal.dir=hdfs://haruna/home/byte_tce_spark/spark_history_server/cloudnative-hl \
    --conf spark.kubernetes.driver.volumes.hostPath.yarn-deploy.options.path=/opt/tiger/yarn_deploy \
    --conf spark.kubernetes.executor.volumes.hostPath.yarn-deploy.mount.path=/opt/tiger/yarn_deploy \
    --conf spark.kubernetes.executor.volumes.hostPath.yarn-deploy.mount.readOnly=true \
    --conf spark.kubernetes.executor.volumes.hostPath.yarn-deploy.options.path=/opt/tiger/yarn_deploy \
    ${USER_DIR}/convertor/convertor.py \
    ${USER_DIR}/convertor/class.csv ${USER_DIR}/convertor/class_tfrecords/