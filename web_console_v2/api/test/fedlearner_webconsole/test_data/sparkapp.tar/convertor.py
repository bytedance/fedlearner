import sys
import logging

from pyspark.sql import SparkSession

def convertor(csv_file: str, tfrecords_file: str):
    spark = SparkSession.builder.appName('SparkByExamples.com').getOrCreate()

    df = spark.read.format('csv').option('header', 'true').option('inferSchema', 'true').load(csv_file)
    df.printSchema()
    df.write.format('tfrecords').save(tfrecords_file, mode='overwrite')

if __name__ == '__main__':
    if len(sys.argv) != 3:
        logging.error(f'spark-submit {sys.argv[0]} [csv_file] [tfrecords_file]')
        sys.exit(-1)

    csv_file, tfrecords_file = sys.argv[1:]
    convertor(csv_file=csv_file, tfrecords_file=tfrecords_file)
