import sys
import os
import logging

from pyspark.sql import SparkSession


def convertor(dataset_path: str):
    spark = SparkSession.builder.getOrCreate()

    csv_file = os.path.join(dataset_path, '*.csv')
    df = spark.read.format('csv').option('header',
                                         'true').option('inferSchema',
                                                        'true').load(csv_file)
    df.printSchema()
    df.write.format('tfrecords').save(f'{dataset_path}/rds/', mode='overwrite')


if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO)
    if len(sys.argv) != 2:
        logging.error(f'spark-submit {sys.argv[0]} [dataset_path]')
        sys.exit(-1)

    dataset_path = sys.argv[1]
    logging.info(f'converting files[{dataset_path}]')
    convertor(dataset_path)
